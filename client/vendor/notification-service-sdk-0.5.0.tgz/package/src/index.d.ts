export interface Slot { /** ISO weekday: 1 = Monday … 7 = Sunday */ day: number; /** HH:mm in the enrolment's timezone */ time: string }
export interface Topic { id: string; slug: string; title: string; description: string; itemCount: number; sensitive: boolean }
export interface Config { tenant: { name: string; slug: string }; vapidPublicKey: string; topics: Topic[]; limits: { maxSlots: number; maxDurationDays: number } }
export interface Device { id: string; endpoint: string; platform: string; browser: string; status: 'active' | 'expired' | 'revoked'; lastSuccessAt: string | null }
export interface Me { id: string; timezone: string | null; locale: string | null; consentAt: string | null; createdAt: string; maxSlots: number; devices: Device[] }
export interface Enrolment {
  id: string; topicId: string; topicTitle?: string; slots: Slot[]; timezone: string; startDate: string; endDate: string;
  position: number; nextSendAt: string | null; status: 'active' | 'paused' | 'completed' | 'cancelled';
}
export interface DeliveryView { id: string; scheduledFor: string; topic: { title: string; slug: string; sensitive: boolean }; body: string; attribution: string | null; rating: 'up' | 'down' | null; comment: string | null }
export interface Support { supported: boolean; reason: null | 'ios_needs_home_screen' | 'unsupported_browser' | 'insecure_context'; browser: string; platform: string; isIOS: boolean; standalone: boolean }
export type SubscribeResult = { status: 'subscribed'; device: Device } | { status: 'denied' | 'dismissed' } | { status: 'unsupported'; reason: Support['reason'] };

export class ApiError extends Error { status: number; code: string; details?: unknown }
export function detectSupport(nav?: Navigator, win?: Window): Support;
export interface Client {
  detectSupport(): Support;
  getConfig(): Promise<Config>;
  permission(): NotificationPermission | 'unsupported';
  currentSubscription(serviceWorkerUrl?: string): Promise<PushSubscription | null>;
  subscribe(opts?: { serviceWorkerUrl?: string }): Promise<SubscribeResult>;
  unsubscribe(opts?: { serviceWorkerUrl?: string }): Promise<boolean>;
  completeProfile(opts?: { timezone?: string; locale?: string }): Promise<Me>;
  getMe(): Promise<Me>;
  eraseMe(): Promise<{ erased: Record<string, number> }>;
  listEnrolments(): Promise<Enrolment[]>;
  createEnrolment(input: { topicId: string; slots: Slot[]; timezone: string; startDate?: string; endDate: string }): Promise<Enrolment>;
  updateEnrolment(id: string, patch: { action?: 'pause' | 'resume' | 'cancel'; slots?: Slot[]; reason?: string }): Promise<Enrolment>;
  getDelivery(id: string, deliveryToken?: string): Promise<DeliveryView>;
  sendFeedback(input: { deliveryId: string; rating?: 'up' | 'down'; text?: string }, deliveryToken?: string): Promise<{ deliveryId: string; rating: 'up' | 'down' | null; text: string | null }>;
  track(type: string, meta?: Record<string, unknown>, opts?: { signedIn?: boolean; deliveryToken?: string }): Promise<void>;
}
export function createClient(opts: { apiBase: string; publishableKey: string; getToken: () => Promise<string> }): Client;
