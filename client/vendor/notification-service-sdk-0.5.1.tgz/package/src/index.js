/**
 * Browser SDK for the notification platform.
 *
 *   const ns = createClient({ apiBase, publishableKey, getToken });
 *   const { topics } = await ns.getConfig();
 *   await ns.subscribe({ serviceWorkerUrl: '/sw.js' });
 *   await ns.createEnrolment({ topicId, slots, timezone, endDate });
 *
 * `getToken` returns a subscriber token that the tenant's backend obtained
 * from POST /v1/subscriber-tokens with its secret key. The SDK never sees the
 * secret key or the tenant's own sign-in credentials.
 */
export class ApiError extends Error {
  constructor(status, code, message, details) { super(message); this.status = status; this.code = code; this.details = details; }
}

const b64urlToBytes = (s) => {
  const pad = '='.repeat((4 - (s.length % 4)) % 4);
  const raw = atob((s + pad).replace(/-/g, '+').replace(/_/g, '/'));
  return Uint8Array.from(raw, (c) => c.charCodeAt(0));
};
const bytesToB64url = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

/** What this browser can do, and why not when it cannot. */
export function detectSupport(nav = navigator, win = window) {
  const ua = nav.userAgent || '';
  const isIOS = /iPad|iPhone|iPod/.test(ua) || (nav.platform === 'MacIntel' && nav.maxTouchPoints > 1);
  const standalone = win.matchMedia?.('(display-mode: standalone)').matches || nav.standalone === true;
  const hasPush = 'serviceWorker' in nav && 'PushManager' in win && 'Notification' in win;
  const browser = /Edg\//.test(ua) ? 'Edge' : /OPR\//.test(ua) ? 'Opera' : /SamsungBrowser/.test(ua) ? 'Samsung Internet'
    : /Firefox\//.test(ua) ? 'Firefox' : /Chrome\//.test(ua) ? 'Chrome' : /Safari\//.test(ua) ? 'Safari' : 'Other';
  const platform = isIOS ? 'iOS' : /Android/.test(ua) ? 'Android' : /Windows/.test(ua) ? 'Windows' : /Mac OS X/.test(ua) ? 'macOS' : /Linux/.test(ua) ? 'Linux' : 'Other';
  let reason = null;
  if (isIOS && !standalone) reason = 'ios_needs_home_screen'; // iOS allows web push only for a site added to the Home Screen
  else if (!hasPush) reason = 'unsupported_browser';
  else if (!win.isSecureContext) reason = 'insecure_context';
  return { supported: reason === null, reason, browser, platform, isIOS, standalone };
}

export function createClient({ apiBase, publishableKey, getToken }) {
  const base = apiBase.replace(/\/$/, '');
  let configPromise = null;
  const anonId = (() => {
    try {
      let id = localStorage.getItem('ns_anon');
      if (!id) { id = crypto.randomUUID(); localStorage.setItem('ns_anon', id); }
      return id;
    } catch { return undefined; }
  })();

  async function call(method, path, { body, auth = 'token', token } = {}) {
    const headers = {};
    if (body !== undefined) headers['content-type'] = 'application/json';
    if (auth === 'key') headers['x-api-key'] = publishableKey;
    else headers.authorization = `Bearer ${token ?? (await getToken())}`;
    const res = await fetch(base + path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
    if (res.status === 204) return null;
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new ApiError(res.status, data.error?.code ?? 'error', data.error?.message ?? `Request failed (${res.status})`, data.error?.details);
    return data;
  }

  const swQuery = () => `api=${encodeURIComponent(base)}&key=${encodeURIComponent(publishableKey)}`;

  return {
    detectSupport: () => detectSupport(),
    /** Tenant name, VAPID public key, public topics and limits. Cached for the page. */
    getConfig: () => (configPromise ??= call('GET', '/v1/config', { auth: 'key' }).catch((e) => { configPromise = null; throw e; })),
    permission: () => (typeof Notification === 'undefined' ? 'unsupported' : Notification.permission),

    /** The current push subscription of this browser, or null. */
    async currentSubscription(serviceWorkerUrl = '/sw.js') {
      if (!('serviceWorker' in navigator)) return null;
      const reg = await navigator.serviceWorker.getRegistration(serviceWorkerUrl);
      return reg ? reg.pushManager.getSubscription() : null;
    },

    /**
     * Registers the service worker, asks for permission, subscribes this
     * browser and stores the subscription on the platform. Call it directly
     * from a click handler, with nothing awaited before it, after the visitor
     * has said what they want.
     * Returns { status: 'subscribed', device } or { status: 'denied' | 'dismissed' | 'unsupported', reason }.
     */
    async subscribe({ serviceWorkerUrl = '/sw.js' } = {}) {
      const support = detectSupport();
      if (!support.supported) return { status: 'unsupported', reason: support.reason };
      // Ask first, before any network call: Safari and Firefox only show the prompt while the click is still "fresh".
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') return { status: permission === 'denied' ? 'denied' : 'dismissed' };
      const cfg = await this.getConfig();
      const reg = await navigator.serviceWorker.register(`${serviceWorkerUrl}?${swQuery()}`);
      await navigator.serviceWorker.ready;
      const key = b64urlToBytes(cfg.vapidPublicKey);
      let sub = await reg.pushManager.getSubscription();
      // A subscription made with another key (an old tenant key) cannot be sent to; replace it.
      if (sub && sub.options.applicationServerKey && bytesToB64url(sub.options.applicationServerKey) !== cfg.vapidPublicKey) {
        await sub.unsubscribe(); sub = null;
      }
      sub ??= await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: key });
      const json = sub.toJSON();
      const device = await call('PUT', '/v1/subscribers/me/devices', {
        body: { endpoint: json.endpoint, keys: json.keys, platform: support.platform, browser: support.browser },
      });
      return { status: 'subscribed', device };
    },

    /** Unsubscribes this browser and revokes its device on the platform. */
    async unsubscribe({ serviceWorkerUrl = '/sw.js' } = {}) {
      const sub = await this.currentSubscription(serviceWorkerUrl);
      if (!sub) return false;
      const me = await call('GET', '/v1/subscribers/me');
      const device = me.devices.find((d) => d.endpoint === sub.endpoint);
      await sub.unsubscribe();
      if (device) await call('DELETE', `/v1/subscribers/me/devices/${device.id}`);
      return true;
    },

    completeProfile: ({ timezone = Intl.DateTimeFormat().resolvedOptions().timeZone, locale = navigator.language } = {}) =>
      call('POST', '/v1/subscribers', { body: { timezone, locale, consent: true } }),
    getMe: () => call('GET', '/v1/subscribers/me'),
    eraseMe: () => call('DELETE', '/v1/subscribers/me'),

    listEnrolments: async () => (await call('GET', '/v1/subscribers/me/enrolments')).enrolments,
    createEnrolment: (input) => call('POST', '/v1/subscribers/me/enrolments', { body: input }),
    updateEnrolment: (id, patch) => call('PATCH', `/v1/enrolments/${id}`, { body: patch }),

    /** Quote-page data for one delivery. `deliveryToken` comes from the notification's click URL. */
    getDelivery: (id, deliveryToken) => call('GET', `/v1/deliveries/${id}`, { token: deliveryToken }),
    sendFeedback: (input, deliveryToken) => call('POST', '/v1/feedback', { body: input, token: deliveryToken }),

    /**
     * Records a funnel event. Never throws: measurement must not break the page.
     * Before sign-in the event is anonymous; pass `{ signedIn: true }` to attach it to the subscriber.
     */
    async track(type, meta = {}, { signedIn = false, deliveryToken } = {}) {
      try {
        const body = { events: [{ type, ts: new Date().toISOString(), anonId, meta }] };
        if (deliveryToken) await call('POST', '/v1/events', { body, token: deliveryToken });
        else if (signedIn) await call('POST', '/v1/events', { body });
        else await call('POST', '/v1/events', { body, auth: 'key' });
      } catch { /* ignore */ }
    },
  };
}
